/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as actions from "../actions.js";
import type * as ai from "../ai.js";
import type * as aiSmoke from "../aiSmoke.js";
import type * as anthropicClient from "../anthropicClient.js";
import type * as assistantActions from "../assistantActions.js";
import type * as auth from "../auth.js";
import type * as auth_emailOtp from "../auth/emailOtp.js";
import type * as consumer from "../consumer.js";
import type * as dast from "../dast.js";
import type * as dast_canonical from "../dast/canonical.js";
import type * as dast_engine from "../dast/engine.js";
import type * as dast_lab from "../dast/lab.js";
import type * as dast_redaction from "../dast/redaction.js";
import type * as dastAi from "../dastAi.js";
import type * as evidenceGraph from "../evidenceGraph.js";
import type * as groqClient from "../groqClient.js";
import type * as groqDiagnostics from "../groqDiagnostics.js";
import type * as http from "../http.js";
import type * as intelligence from "../intelligence.js";
import type * as intelligenceActions from "../intelligenceActions.js";
import type * as jaal from "../jaal.js";
import type * as lib_backend from "../lib/backend.js";
import type * as lib_intelligence from "../lib/intelligence.js";
import type * as lib_intelligenceSchemas from "../lib/intelligenceSchemas.js";
import type * as protection from "../protection.js";
import type * as sttDiagnostics from "../sttDiagnostics.js";
import type * as users from "../users.js";
import type * as voice from "../voice.js";
import type * as voiceActions from "../voiceActions.js";
import type * as voiceIntake from "../voiceIntake.js";
import type * as voicePipeline from "../voicePipeline.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";

declare const fullApi: ApiFromModules<{
  actions: typeof actions;
  ai: typeof ai;
  aiSmoke: typeof aiSmoke;
  anthropicClient: typeof anthropicClient;
  assistantActions: typeof assistantActions;
  auth: typeof auth;
  "auth/emailOtp": typeof auth_emailOtp;
  consumer: typeof consumer;
  dast: typeof dast;
  "dast/canonical": typeof dast_canonical;
  "dast/engine": typeof dast_engine;
  "dast/lab": typeof dast_lab;
  "dast/redaction": typeof dast_redaction;
  dastAi: typeof dastAi;
  evidenceGraph: typeof evidenceGraph;
  groqClient: typeof groqClient;
  groqDiagnostics: typeof groqDiagnostics;
  http: typeof http;
  intelligence: typeof intelligence;
  intelligenceActions: typeof intelligenceActions;
  jaal: typeof jaal;
  "lib/backend": typeof lib_backend;
  "lib/intelligence": typeof lib_intelligence;
  "lib/intelligenceSchemas": typeof lib_intelligenceSchemas;
  protection: typeof protection;
  sttDiagnostics: typeof sttDiagnostics;
  users: typeof users;
  voice: typeof voice;
  voiceActions: typeof voiceActions;
  voiceIntake: typeof voiceIntake;
  voicePipeline: typeof voicePipeline;
}>;

/**
 * A utility for referencing Convex functions in your app's public API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;

/**
 * A utility for referencing Convex functions in your app's internal API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = internal.myModule.myFunction;
 * ```
 */
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;

export declare const components: {};
