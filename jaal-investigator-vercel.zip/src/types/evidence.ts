export type EvidenceType =
  | "upi"
  | "phone"
  | "url"
  | "email"
  | "payment_request"
  | "scam_message"
  | "transcript"
  | "other";

/**
 * Hash lifecycle only — a hash proves the content has not changed since it was
 * recorded. It does not prove the identifier is genuine or that any person
 * committed a crime.
 */
export type HashStatus =
  | "none" // evidence collected, no hash yet
  | "generated" // hash recorded — NOT yet independently verified
  | "verified" // recomputed hash matches recorded hash
  | "mismatch" // recomputed hash differs from recorded hash
  | "tampered"; // content altered through the explicit tamper-simulation path

/** Analyst verdict — stored separately from the original extraction. */
export type EvidenceReviewStatus = "confirmed" | "incorrect" | "needs_review";

export interface EvidenceItem {
  id: string;
  caseId: string;
  type: EvidenceType;
  /** Short human label, e.g. "UPI ID" */
  label: string;
  /** The extracted value itself */
  value: string;
  /** Canonical content that gets hashed (value + source context) */
  content: string;
  sourceMessageId: string | null;
  sourceMessageText: string;
  /** Epoch ms */
  extractedAt: number;
  /** Unverified lead until a hash is generated and checked */
  notes: string;
  hash: string | null;
  hashGeneratedAt: number | null;
  hashStatus: HashStatus;
  /** How the indicator was found, e.g. RULE_BASED_REGEX:url_obfuscated. */
  detectionMethod?: string | null;
  /** Heuristic extraction confidence in [0,1] — a review aid, not a fraud verdict. */
  confidence?: number | null;
  /** Set when the analyst edited content on purpose to demo a mismatch */
  tampered?: boolean;
  reviewStatus?: EvidenceReviewStatus | null;
  reviewNote?: string | null;
  reviewedAt?: number | null;
}

export type EvidenceFilter =
  | "all"
  | "upi"
  | "phone"
  | "url"
  | "email"
  | "message"
  | "transcript"
  | "payment"
  | "verified"
  | "unverified";
